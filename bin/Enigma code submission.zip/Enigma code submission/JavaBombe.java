/**This is the code we are mainly focused on, designed to crack the codes presets using an 
encoded message and the message's decrypted word, known as a crib or key. It is still
a work of progress and this is what it looks like as of 9:00 am May 16th.
Authors: Trevor Ward / Jackie Cheng
*/
import java.util.Scanner;

public class JavaBombe
{
	public static void main(String []args)
	{
		Scanner input = new Scanner(System.in);

		Rotors rtr = new Rotors();
		String code;
		String crib;
		boolean bombe = false;
		char [] pB = new char [26];
		char [] message;
		char [] key;

		System.out.println("Enter the encrypted message.");
		code = input.nextLine();

		System.out.println("Enter the crib word.");
		crib = input.nextLine();

		message = new char [code.length()];
		for(int i=0;i<message.length;i++)
		{
			message[i] = code.charAt(i);
		}

		key = new char [crib.length()];
		for(int i=0;i<key.length;i++)
		{
			key[i] = crib.charAt(i);
		}






		}

		public static void GO()
		{
			while(bombe = false)
			{
				for(int i=1;i<=60;i++)
				{
					for(int j=1;i<=17576;i++)
					{
						for(int k=1;k<=26;k++)
						{

						}
					}
				}

			}

	}
}