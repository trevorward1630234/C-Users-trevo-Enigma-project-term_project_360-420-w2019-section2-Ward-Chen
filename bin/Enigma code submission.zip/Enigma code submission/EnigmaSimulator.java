/**This code essentilly simulates the Enigma encryption machine. Just like the
real machine, it allows the user to choose from a possible 150 * 10^18+ presets 
and put in a message, then encrypting it. If the encrypted message is put into
the code with the same starting presets, the result is the original message.
It uses the Rotors class.
Authors: Trevor Ward / Jackie Cheng
*/
import java.util.*;
import java.util.Scanner;

public class EnigmaSimulator
{
	public static void main(String []args)
	{
		Scanner keyboard = new Scanner(System.in);
		String message;
		char letter;
		char [] pB = new char [26];
		int [] rotorSelect = new int[3];
		int [] preset = new int[3];
		int value;
		

		pB = plugBoard(pB);

		rotorSelect = rotorSelection(rotorSelect); //array containing rotors at each position.

		preset = presets(preset); // array containing rotor presets

		System.out.println("Enter message to be coded.");
		message = keyboard.nextLine();


		GO(message,pB,rotorSelect,preset);

		
	}

	public static char[] plugBoard(char [] message)
	{
		Scanner keyboard = new Scanner(System.in);
		char pBLetter = 'A';
		boolean pbError = true;
		for(int i=0;i<message.length;i++)
		{
			int j =0;
			pBLetter = (char)('A'+ i);
			System.out.println("Which letter connects to " + pBLetter + "?");
			message[i] = keyboard.next().charAt(0);

			while(j<i)
			{
				while (message[i]==message[j])
				{
					System.out.println("Letters can only be connected to one other letter or not at all. Which letter connects to " + pBLetter + "?");
					message[i] = keyboard.next().charAt(0);
				}
				j++;
			}
		}

		return message;
	}

	public static int [] rotorSelection(int[] array)
	{
		Scanner keyboard = new Scanner(System.in);
		for(int i=0;i<array.length;i++)
		{
			int j=0;
			System.out.println("Which rotor goes into rotor position " + (i+1) + "?");
			array[i] = keyboard.nextInt();

			while(array[i]<1 || array[i]>5)
			{
				System.out.println("Please pick a rotor from 1 to 5. Which rotor goes into rotor position " + (i+1) + "?");
				array[i] = keyboard.nextInt();
			}

			while(j<i)
			{
				while (array[i]==array[j])
				{
					System.out.println("That rotor has already been picked. Pick another one for rotor position " + (i+1) + "?");
					array[i] = keyboard.nextInt();
				}
				j++;
			}
		}

		return array;
	}

	public static int [] presets(int[] array)
	{
		Scanner keyboard = new Scanner(System.in);
		for(int i=0;i<array.length;i++)
		{
			System.out.println("Select preset for rotor " + (i +1));
			array[i] = keyboard.nextInt();

			while(array[i]<1 || array[i]>25)
			{
				System.out.println("Please pick a rotor preset from 1 to 26. Select preset for rotor " + (i+1) + "?");
				array[i] = keyboard.nextInt();
			}
		}

		return array;
	}

	public static void GO(String message, char [] plugboard, int[] rotors, int[] presets)
	{
		Scanner keyboard = new Scanner(System.in);
		char lampBoard;
		char letter;
		int value;
		Rotors rtr = new Rotors();

		for (int i =0;i<message.length();i++)
		{
			presets[0]=presets[0]+1;
			
			if(presets[0]==27)
			{
				presets[0]=1;
				presets[1]=presets[1]+1;
			}
			if(presets[1]==27)
			{
				presets[1]=1;
				presets[2]=presets[2]+1;
			}
			if(presets[2]==27)
			{
				presets[2]=1;
			}

			if(rotors[0]==1)
			{
				if(rotors[1]==2)
				{
					if(rotors[2]==3)
					{
						letter = message.charAt(i);		
						letter = plugboard[rtr.alphabet(letter)-1];
						value = rtr.alphabet(letter);
						value = rtr.rotor1(value,presets[0]);
						value = rtr.rotor2(value,presets[1]);
						value = rtr.rotor3(value,presets[2]);
						letter = rtr.alphabetInv(value);
						value = rtr.reflectorUKWC(letter);
						value = rtr.rotor3Inverse(value,presets[2]);
						value = rtr.rotor2Inverse(value,presets[1]);
						value = rtr.rotor1Inverse(value,presets[0]);
						letter = rtr.alphabetInv(value);
						lampBoard = plugboard[rtr.alphabet(letter)-1];
						System.out.print(lampBoard); 
					}

					if(rotors[2]==4)
					{
						letter = message.charAt(i);		
						letter = plugboard[rtr.alphabet(letter)-1];
						value = rtr.alphabet(letter);
						value = rtr.rotor1(value,presets[0]);
						value = rtr.rotor2(value,presets[1]);
						value = rtr.rotor4(value,presets[2]);
						letter = rtr.alphabetInv(value);
						value = rtr.reflectorUKWC(letter);
						value = rtr.rotor4Inverse(value,presets[2]);
						value = rtr.rotor2Inverse(value,presets[1]);
						value = rtr.rotor1Inverse(value,presets[0]);
						letter = rtr.alphabetInv(value);
						lampBoard = plugboard[rtr.alphabet(letter)-1];
						System.out.print(lampBoard); 
					}

					if(rotors[2]==5)
					{
						letter = message.charAt(i);		
						letter = plugboard[rtr.alphabet(letter)-1];
						value = rtr.alphabet(letter);
						value = rtr.rotor1(value,presets[0]);
						value = rtr.rotor2(value,presets[1]);
						value = rtr.rotor5(value,presets[2]);
						letter = rtr.alphabetInv(value);
						value = rtr.reflectorUKWC(letter);
						value = rtr.rotor5Inverse(value,presets[2]);
						value = rtr.rotor2Inverse(value,presets[1]);
						value = rtr.rotor1Inverse(value,presets[0]);
						letter = rtr.alphabetInv(value);
						lampBoard = plugboard[rtr.alphabet(letter)-1];
						System.out.print(lampBoard); 
					}
				}
				if(rotors[1]==3)
				{
					if(rotors[2]==2)
					{
						letter = message.charAt(i);		
						letter = plugboard[rtr.alphabet(letter)-1];
						value = rtr.alphabet(letter);
						value = rtr.rotor1(value,presets[0]);
						value = rtr.rotor3(value,presets[1]);
						value = rtr.rotor2(value,presets[2]);
						letter = rtr.alphabetInv(value);
						value = rtr.reflectorUKWC(letter);
						value = rtr.rotor2Inverse(value,presets[2]);
						value = rtr.rotor3Inverse(value,presets[1]);
						value = rtr.rotor1Inverse(value,presets[0]);
						letter = rtr.alphabetInv(value);
						lampBoard = plugboard[rtr.alphabet(letter)-1];
						System.out.print(lampBoard); 
					}

					if(rotors[2]==4)
					{
						letter = message.charAt(i);		
						letter = plugboard[rtr.alphabet(letter)-1];
						value = rtr.alphabet(letter);
						value = rtr.rotor1(value,presets[0]);
						value = rtr.rotor3(value,presets[1]);
						value = rtr.rotor4(value,presets[2]);
						letter = rtr.alphabetInv(value);
						value = rtr.reflectorUKWC(letter);
						value = rtr.rotor4Inverse(value,presets[2]);
						value = rtr.rotor3Inverse(value,presets[1]);
						value = rtr.rotor1Inverse(value,presets[0]);
						letter = rtr.alphabetInv(value);
						lampBoard = plugboard[rtr.alphabet(letter)-1];
						System.out.print(lampBoard); 
					}

					if(rotors[2]==5)
					{
						letter = message.charAt(i);		
						letter = plugboard[rtr.alphabet(letter)-1];
						value = rtr.alphabet(letter);
						value = rtr.rotor1(value,presets[0]);
						value = rtr.rotor3(value,presets[1]);
						value = rtr.rotor5(value,presets[2]);
						letter = rtr.alphabetInv(value);
						value = rtr.reflectorUKWC(letter);
						value = rtr.rotor5Inverse(value,presets[2]);
						value = rtr.rotor3Inverse(value,presets[1]);
						value = rtr.rotor1Inverse(value,presets[0]);
						letter = rtr.alphabetInv(value);
						lampBoard = plugboard[rtr.alphabet(letter)-1];
						System.out.print(lampBoard); 
					}
				}
				if(rotors[1]==4)
				{
					if(rotors[2]==2)
					{
						letter = message.charAt(i);		
						letter = plugboard[rtr.alphabet(letter)-1];
						value = rtr.alphabet(letter);
						value = rtr.rotor1(value,presets[0]);
						value = rtr.rotor4(value,presets[1]);
						value = rtr.rotor2(value,presets[2]);
						letter = rtr.alphabetInv(value);
						value = rtr.reflectorUKWC(letter);
						value = rtr.rotor2Inverse(value,presets[2]);
						value = rtr.rotor4Inverse(value,presets[1]);
						value = rtr.rotor1Inverse(value,presets[0]);
						letter = rtr.alphabetInv(value);
						lampBoard = plugboard[rtr.alphabet(letter)-1];
						System.out.print(lampBoard); 
					}

					if(rotors[2]==3)
					{
						letter = message.charAt(i);		
						letter = plugboard[rtr.alphabet(letter)-1];
						value = rtr.alphabet(letter);
						value = rtr.rotor1(value,presets[0]);
						value = rtr.rotor4(value,presets[1]);
						value = rtr.rotor3(value,presets[2]);
						letter = rtr.alphabetInv(value);
						value = rtr.reflectorUKWC(letter);
						value = rtr.rotor3Inverse(value,presets[2]);
						value = rtr.rotor4Inverse(value,presets[1]);
						value = rtr.rotor1Inverse(value,presets[0]);
						letter = rtr.alphabetInv(value);
						lampBoard = plugboard[rtr.alphabet(letter)-1];
						System.out.print(lampBoard); 
					}

					if(rotors[2]==5)
					{
						letter = message.charAt(i);		
						letter = plugboard[rtr.alphabet(letter)-1];
						value = rtr.alphabet(letter);
						value = rtr.rotor1(value,presets[0]);
						value = rtr.rotor4(value,presets[1]);
						value = rtr.rotor5(value,presets[2]);
						letter = rtr.alphabetInv(value);
						value = rtr.reflectorUKWC(letter);
						value = rtr.rotor5Inverse(value,presets[2]);
						value = rtr.rotor4Inverse(value,presets[1]);
						value = rtr.rotor1Inverse(value,presets[0]);
						letter = rtr.alphabetInv(value);
						lampBoard = plugboard[rtr.alphabet(letter)-1];
						System.out.print(lampBoard); 
					}
				}
				if(rotors[1]==5)
				{
					if(rotors[2]==2)
					{
						letter = message.charAt(i);		
						letter = plugboard[rtr.alphabet(letter)-1];
						value = rtr.alphabet(letter);
						value = rtr.rotor1(value,presets[0]);
						value = rtr.rotor5(value,presets[1]);
						value = rtr.rotor2(value,presets[2]);
						letter = rtr.alphabetInv(value);
						value = rtr.reflectorUKWC(letter);
						value = rtr.rotor2Inverse(value,presets[2]);
						value = rtr.rotor5Inverse(value,presets[1]);
						value = rtr.rotor1Inverse(value,presets[0]);
						letter = rtr.alphabetInv(value);
						lampBoard = plugboard[rtr.alphabet(letter)-1];
						System.out.print(lampBoard); 
					}

					if(rotors[2]==3)
					{
						letter = message.charAt(i);		
						letter = plugboard[rtr.alphabet(letter)-1];
						value = rtr.alphabet(letter);
						value = rtr.rotor1(value,presets[0]);
						value = rtr.rotor5(value,presets[1]);
						value = rtr.rotor3(value,presets[2]);
						letter = rtr.alphabetInv(value);
						value = rtr.reflectorUKWC(letter);
						value = rtr.rotor3Inverse(value,presets[2]);
						value = rtr.rotor5Inverse(value,presets[1]);
						value = rtr.rotor1Inverse(value,presets[0]);
						letter = rtr.alphabetInv(value);
						lampBoard = plugboard[rtr.alphabet(letter)-1];
						System.out.print(lampBoard); 
					}

					if(rotors[2]==4)
					{
						letter = message.charAt(i);		
						letter = plugboard[rtr.alphabet(letter)-1];
						value = rtr.alphabet(letter);
						value = rtr.rotor1(value,presets[0]);
						value = rtr.rotor5(value,presets[1]);
						value = rtr.rotor4(value,presets[2]);
						letter = rtr.alphabetInv(value);
						value = rtr.reflectorUKWC(letter);
						value = rtr.rotor4Inverse(value,presets[2]);
						value = rtr.rotor5Inverse(value,presets[1]);
						value = rtr.rotor1Inverse(value,presets[0]);
						letter = rtr.alphabetInv(value);
						lampBoard = plugboard[rtr.alphabet(letter)-1];
						System.out.print(lampBoard); 
					}
				}
			}
			if(rotors[0]==2)
			{
				if(rotors[1]==1)
				{
					if(rotors[2]==3)
					{
						letter = message.charAt(i);		
						letter = plugboard[rtr.alphabet(letter)-1];
						value = rtr.alphabet(letter);
						value = rtr.rotor2(value,presets[0]);
						value = rtr.rotor1(value,presets[1]);
						value = rtr.rotor3(value,presets[2]);
						letter = rtr.alphabetInv(value);
						value = rtr.reflectorUKWC(letter);
						value = rtr.rotor3Inverse(value,presets[2]);
						value = rtr.rotor1Inverse(value,presets[1]);
						value = rtr.rotor2Inverse(value,presets[0]);
						letter = rtr.alphabetInv(value);
						lampBoard = plugboard[rtr.alphabet(letter)-1];
						System.out.print(lampBoard); 
					}

					if(rotors[2]==4)
					{
						letter = message.charAt(i);		
						letter = plugboard[rtr.alphabet(letter)-1];
						value = rtr.alphabet(letter);
						value = rtr.rotor2(value,presets[0]);
						value = rtr.rotor1(value,presets[1]);
						value = rtr.rotor4(value,presets[2]);
						letter = rtr.alphabetInv(value);
						value = rtr.reflectorUKWC(letter);
						value = rtr.rotor4Inverse(value,presets[2]);
						value = rtr.rotor1Inverse(value,presets[1]);
						value = rtr.rotor2Inverse(value,presets[0]);
						letter = rtr.alphabetInv(value);
						lampBoard = plugboard[rtr.alphabet(letter)-1];
						System.out.print(lampBoard); 
					}

					if(rotors[2]==5)
					{
						letter = message.charAt(i);		
						letter = plugboard[rtr.alphabet(letter)-1];
						value = rtr.alphabet(letter);
						value = rtr.rotor2(value,presets[0]);
						value = rtr.rotor1(value,presets[1]);
						value = rtr.rotor5(value,presets[2]);
						letter = rtr.alphabetInv(value);
						value = rtr.reflectorUKWC(letter);
						value = rtr.rotor5Inverse(value,presets[2]);
						value = rtr.rotor1Inverse(value,presets[1]);
						value = rtr.rotor2Inverse(value,presets[0]);
						letter = rtr.alphabetInv(value);
						lampBoard = plugboard[rtr.alphabet(letter)-1];
						System.out.print(lampBoard); 
					}
				}
				if(rotors[1]==3)
				{
					if(rotors[2]==1)
					{
						letter = message.charAt(i);		
						letter = plugboard[rtr.alphabet(letter)-1];
						value = rtr.alphabet(letter);
						value = rtr.rotor2(value,presets[0]);
						value = rtr.rotor3(value,presets[1]);
						value = rtr.rotor1(value,presets[2]);
						letter = rtr.alphabetInv(value);
						value = rtr.reflectorUKWC(letter);
						value = rtr.rotor1Inverse(value,presets[2]);
						value = rtr.rotor3Inverse(value,presets[1]);
						value = rtr.rotor2Inverse(value,presets[0]);
						letter = rtr.alphabetInv(value);
						lampBoard = plugboard[rtr.alphabet(letter)-1];
						System.out.print(lampBoard); 
					}

					if(rotors[2]==4)
					{
						letter = message.charAt(i);		
						letter = plugboard[rtr.alphabet(letter)-1];
						value = rtr.alphabet(letter);
						value = rtr.rotor2(value,presets[0]);
						value = rtr.rotor3(value,presets[1]);
						value = rtr.rotor4(value,presets[2]);
						letter = rtr.alphabetInv(value);
						value = rtr.reflectorUKWC(letter);
						value = rtr.rotor4Inverse(value,presets[2]);
						value = rtr.rotor3Inverse(value,presets[1]);
						value = rtr.rotor2Inverse(value,presets[0]);
						letter = rtr.alphabetInv(value);
						lampBoard = plugboard[rtr.alphabet(letter)-1];
						System.out.print(lampBoard); 
					}

					if(rotors[2]==5)
					{
						letter = message.charAt(i);		
						letter = plugboard[rtr.alphabet(letter)-1];
						value = rtr.alphabet(letter);
						value = rtr.rotor2(value,presets[0]);
						value = rtr.rotor3(value,presets[1]);
						value = rtr.rotor5(value,presets[2]);
						letter = rtr.alphabetInv(value);
						value = rtr.reflectorUKWC(letter);
						value = rtr.rotor5Inverse(value,presets[2]);
						value = rtr.rotor3Inverse(value,presets[1]);
						value = rtr.rotor2Inverse(value,presets[0]);
						letter = rtr.alphabetInv(value);
						lampBoard = plugboard[rtr.alphabet(letter)-1];
						System.out.print(lampBoard); 
					}
				}
				if(rotors[1]==4)
				{
					if(rotors[2]==1)
					{
						letter = message.charAt(i);		
						letter = plugboard[rtr.alphabet(letter)-1];
						value = rtr.alphabet(letter);
						value = rtr.rotor2(value,presets[0]);
						value = rtr.rotor4(value,presets[1]);
						value = rtr.rotor1(value,presets[2]);
						letter = rtr.alphabetInv(value);
						value = rtr.reflectorUKWC(letter);
						value = rtr.rotor1Inverse(value,presets[2]);
						value = rtr.rotor4Inverse(value,presets[1]);
						value = rtr.rotor2Inverse(value,presets[0]);
						letter = rtr.alphabetInv(value);
						lampBoard = plugboard[rtr.alphabet(letter)-1];
						System.out.print(lampBoard); 
					}

					if(rotors[2]==3)
					{
						letter = message.charAt(i);		
						letter = plugboard[rtr.alphabet(letter)-1];
						value = rtr.alphabet(letter);
						value = rtr.rotor2(value,presets[0]);
						value = rtr.rotor4(value,presets[1]);
						value = rtr.rotor3(value,presets[2]);
						letter = rtr.alphabetInv(value);
						value = rtr.reflectorUKWC(letter);
						value = rtr.rotor3Inverse(value,presets[2]);
						value = rtr.rotor4Inverse(value,presets[1]);
						value = rtr.rotor2Inverse(value,presets[0]);
						letter = rtr.alphabetInv(value);
						lampBoard = plugboard[rtr.alphabet(letter)-1];
						System.out.print(lampBoard); 
					}

					if(rotors[2]==5)
					{
						letter = message.charAt(i);		
						letter = plugboard[rtr.alphabet(letter)-1];
						value = rtr.alphabet(letter);
						value = rtr.rotor2(value,presets[0]);
						value = rtr.rotor4(value,presets[1]);
						value = rtr.rotor5(value,presets[2]);
						letter = rtr.alphabetInv(value);
						value = rtr.reflectorUKWC(letter);
						value = rtr.rotor5Inverse(value,presets[2]);
						value = rtr.rotor4Inverse(value,presets[1]);
						value = rtr.rotor2Inverse(value,presets[0]);
						letter = rtr.alphabetInv(value);
						lampBoard = plugboard[rtr.alphabet(letter)-1];
						System.out.print(lampBoard); 
					}
				}
				if(rotors[1]==5)
				{
					if(rotors[2]==1)
					{
						letter = message.charAt(i);		
						letter = plugboard[rtr.alphabet(letter)-1];
						value = rtr.alphabet(letter);
						value = rtr.rotor2(value,presets[0]);
						value = rtr.rotor5(value,presets[1]);
						value = rtr.rotor1(value,presets[2]);
						letter = rtr.alphabetInv(value);
						value = rtr.reflectorUKWC(letter);
						value = rtr.rotor1Inverse(value,presets[2]);
						value = rtr.rotor5Inverse(value,presets[1]);
						value = rtr.rotor2Inverse(value,presets[0]);
						letter = rtr.alphabetInv(value);
						lampBoard = plugboard[rtr.alphabet(letter)-1];
						System.out.print(lampBoard); 
					}

					if(rotors[2]==3)
					{
						letter = message.charAt(i);		
						letter = plugboard[rtr.alphabet(letter)-1];
						value = rtr.alphabet(letter);
						value = rtr.rotor2(value,presets[0]);
						value = rtr.rotor5(value,presets[1]);
						value = rtr.rotor3(value,presets[2]);
						letter = rtr.alphabetInv(value);
						value = rtr.reflectorUKWC(letter);
						value = rtr.rotor3Inverse(value,presets[2]);
						value = rtr.rotor5Inverse(value,presets[1]);
						value = rtr.rotor2Inverse(value,presets[0]);
						letter = rtr.alphabetInv(value);
						lampBoard = plugboard[rtr.alphabet(letter)-1];
						System.out.print(lampBoard); 
					}

					if(rotors[2]==4)
					{
						letter = message.charAt(i);		
						letter = plugboard[rtr.alphabet(letter)-1];
						value = rtr.alphabet(letter);
						value = rtr.rotor2(value,presets[0]);
						value = rtr.rotor5(value,presets[1]);
						value = rtr.rotor4(value,presets[2]);
						letter = rtr.alphabetInv(value);
						value = rtr.reflectorUKWC(letter);
						value = rtr.rotor4Inverse(value,presets[2]);
						value = rtr.rotor5Inverse(value,presets[1]);
						value = rtr.rotor2Inverse(value,presets[0]);
						letter = rtr.alphabetInv(value);
						lampBoard = plugboard[rtr.alphabet(letter)-1];
						System.out.print(lampBoard); 
					}
				}
			}

			if(rotors[0]==3)
			{
				if(rotors[1]==1)
				{
					if(rotors[2]==2)
					{
						letter = message.charAt(i);		
						letter = plugboard[rtr.alphabet(letter)-1];
						value = rtr.alphabet(letter);
						value = rtr.rotor3(value,presets[0]);
						value = rtr.rotor1(value,presets[1]);
						value = rtr.rotor2(value,presets[2]);
						letter = rtr.alphabetInv(value);
						value = rtr.reflectorUKWC(letter);
						value = rtr.rotor2Inverse(value,presets[2]);
						value = rtr.rotor1Inverse(value,presets[1]);
						value = rtr.rotor3Inverse(value,presets[0]);
						letter = rtr.alphabetInv(value);
						lampBoard = plugboard[rtr.alphabet(letter)-1];
						System.out.print(lampBoard); 
					}

					if(rotors[2]==4)
					{
						letter = message.charAt(i);		
						letter = plugboard[rtr.alphabet(letter)-1];
						value = rtr.alphabet(letter);
						value = rtr.rotor3(value,presets[0]);
						value = rtr.rotor1(value,presets[1]);
						value = rtr.rotor4(value,presets[2]);
						letter = rtr.alphabetInv(value);
						value = rtr.reflectorUKWC(letter);
						value = rtr.rotor4Inverse(value,presets[2]);
						value = rtr.rotor1Inverse(value,presets[1]);
						value = rtr.rotor3Inverse(value,presets[0]);
						letter = rtr.alphabetInv(value);
						lampBoard = plugboard[rtr.alphabet(letter)-1];
						System.out.print(lampBoard); 
					}

					if(rotors[2]==5)
					{
						letter = message.charAt(i);		
						letter = plugboard[rtr.alphabet(letter)-1];
						value = rtr.alphabet(letter);
						value = rtr.rotor3(value,presets[0]);
						value = rtr.rotor1(value,presets[1]);
						value = rtr.rotor5(value,presets[2]);
						letter = rtr.alphabetInv(value);
						value = rtr.reflectorUKWC(letter);
						value = rtr.rotor5Inverse(value,presets[2]);
						value = rtr.rotor1Inverse(value,presets[1]);
						value = rtr.rotor3Inverse(value,presets[0]);
						letter = rtr.alphabetInv(value);
						lampBoard = plugboard[rtr.alphabet(letter)-1];
						System.out.print(lampBoard); 
					}
				}
				if(rotors[1]==2)
				{
					if(rotors[2]==1)
					{
						letter = message.charAt(i);		
						letter = plugboard[rtr.alphabet(letter)-1];
						value = rtr.alphabet(letter);
						value = rtr.rotor3(value,presets[0]);
						value = rtr.rotor2(value,presets[1]);
						value = rtr.rotor1(value,presets[2]);
						letter = rtr.alphabetInv(value);
						value = rtr.reflectorUKWC(letter);
						value = rtr.rotor1Inverse(value,presets[2]);
						value = rtr.rotor2Inverse(value,presets[1]);
						value = rtr.rotor3Inverse(value,presets[0]);
						letter = rtr.alphabetInv(value);
						lampBoard = plugboard[rtr.alphabet(letter)-1];
						System.out.print(lampBoard); 
					}

					if(rotors[2]==4)
					{
						letter = message.charAt(i);		
						letter = plugboard[rtr.alphabet(letter)-1];
						value = rtr.alphabet(letter);
						value = rtr.rotor3(value,presets[0]);
						value = rtr.rotor2(value,presets[1]);
						value = rtr.rotor4(value,presets[2]);
						letter = rtr.alphabetInv(value);
						value = rtr.reflectorUKWC(letter);
						value = rtr.rotor4Inverse(value,presets[2]);
						value = rtr.rotor2Inverse(value,presets[1]);
						value = rtr.rotor3Inverse(value,presets[0]);
						letter = rtr.alphabetInv(value);
						lampBoard = plugboard[rtr.alphabet(letter)-1];
						System.out.print(lampBoard); 
					}

					if(rotors[2]==5)
					{
						letter = message.charAt(i);		
						letter = plugboard[rtr.alphabet(letter)-1];
						value = rtr.alphabet(letter);
						value = rtr.rotor3(value,presets[0]);
						value = rtr.rotor2(value,presets[1]);
						value = rtr.rotor5(value,presets[2]);
						letter = rtr.alphabetInv(value);
						value = rtr.reflectorUKWC(letter);
						value = rtr.rotor5Inverse(value,presets[2]);
						value = rtr.rotor2Inverse(value,presets[1]);
						value = rtr.rotor3Inverse(value,presets[0]);
						letter = rtr.alphabetInv(value);
						lampBoard = plugboard[rtr.alphabet(letter)-1];
						System.out.print(lampBoard); 
					}
				}
				if(rotors[1]==4)
				{
					if(rotors[2]==1)
					{
						letter = message.charAt(i);		
						letter = plugboard[rtr.alphabet(letter)-1];
						value = rtr.alphabet(letter);
						value = rtr.rotor3(value,presets[0]);
						value = rtr.rotor4(value,presets[1]);
						value = rtr.rotor1(value,presets[2]);
						letter = rtr.alphabetInv(value);
						value = rtr.reflectorUKWC(letter);
						value = rtr.rotor1Inverse(value,presets[2]);
						value = rtr.rotor4Inverse(value,presets[1]);
						value = rtr.rotor3Inverse(value,presets[0]);
						letter = rtr.alphabetInv(value);
						lampBoard = plugboard[rtr.alphabet(letter)-1];
						System.out.print(lampBoard); 
					}

					if(rotors[2]==2)
					{
						letter = message.charAt(i);		
						letter = plugboard[rtr.alphabet(letter)-1];
						value = rtr.alphabet(letter);
						value = rtr.rotor3(value,presets[0]);
						value = rtr.rotor4(value,presets[1]);
						value = rtr.rotor2(value,presets[2]);
						letter = rtr.alphabetInv(value);
						value = rtr.reflectorUKWC(letter);
						value = rtr.rotor2Inverse(value,presets[2]);
						value = rtr.rotor4Inverse(value,presets[1]);
						value = rtr.rotor3Inverse(value,presets[0]);
						letter = rtr.alphabetInv(value);
						lampBoard = plugboard[rtr.alphabet(letter)-1];
						System.out.print(lampBoard); 
					}

					if(rotors[2]==5)
					{
						letter = message.charAt(i);		
						letter = plugboard[rtr.alphabet(letter)-1];
						value = rtr.alphabet(letter);
						value = rtr.rotor3(value,presets[0]);
						value = rtr.rotor4(value,presets[1]);
						value = rtr.rotor5(value,presets[2]);
						letter = rtr.alphabetInv(value);
						value = rtr.reflectorUKWC(letter);
						value = rtr.rotor5Inverse(value,presets[2]);
						value = rtr.rotor4Inverse(value,presets[1]);
						value = rtr.rotor3Inverse(value,presets[0]);
						letter = rtr.alphabetInv(value);
						lampBoard = plugboard[rtr.alphabet(letter)-1];
						System.out.print(lampBoard); 
					}
				}
				if(rotors[1]==5)
				{
					if(rotors[2]==1)
					{
						letter = message.charAt(i);		
						letter = plugboard[rtr.alphabet(letter)-1];
						value = rtr.alphabet(letter);
						value = rtr.rotor3(value,presets[0]);
						value = rtr.rotor5(value,presets[1]);
						value = rtr.rotor1(value,presets[2]);
						letter = rtr.alphabetInv(value);
						value = rtr.reflectorUKWC(letter);
						value = rtr.rotor1Inverse(value,presets[2]);
						value = rtr.rotor5Inverse(value,presets[1]);
						value = rtr.rotor3Inverse(value,presets[0]);
						letter = rtr.alphabetInv(value);
						lampBoard = plugboard[rtr.alphabet(letter)-1];
						System.out.print(lampBoard); 
					}

					if(rotors[2]==2)
					{
						letter = message.charAt(i);		
						letter = plugboard[rtr.alphabet(letter)-1];
						value = rtr.alphabet(letter);
						value = rtr.rotor3(value,presets[0]);
						value = rtr.rotor5(value,presets[1]);
						value = rtr.rotor2(value,presets[2]);
						letter = rtr.alphabetInv(value);
						value = rtr.reflectorUKWC(letter);
						value = rtr.rotor2Inverse(value,presets[2]);
						value = rtr.rotor5Inverse(value,presets[1]);
						value = rtr.rotor3Inverse(value,presets[0]);
						letter = rtr.alphabetInv(value);
						lampBoard = plugboard[rtr.alphabet(letter)-1];
						System.out.print(lampBoard); 
					}

					if(rotors[2]==4)
					{
						letter = message.charAt(i);		
						letter = plugboard[rtr.alphabet(letter)-1];
						value = rtr.alphabet(letter);
						value = rtr.rotor3(value,presets[0]);
						value = rtr.rotor5(value,presets[1]);
						value = rtr.rotor4(value,presets[2]);
						letter = rtr.alphabetInv(value);
						value = rtr.reflectorUKWC(letter);
						value = rtr.rotor4Inverse(value,presets[2]);
						value = rtr.rotor5Inverse(value,presets[1]);
						value = rtr.rotor3Inverse(value,presets[0]);
						letter = rtr.alphabetInv(value);
						lampBoard = plugboard[rtr.alphabet(letter)-1];
						System.out.print(lampBoard); 
					}
				}
			}

			if(rotors[0]==4)
			{
				if(rotors[1]==1)
				{
					if(rotors[2]==2)
					{
						letter = message.charAt(i);		
						letter = plugboard[rtr.alphabet(letter)-1];
						value = rtr.alphabet(letter);
						value = rtr.rotor4(value,presets[0]);
						value = rtr.rotor1(value,presets[1]);
						value = rtr.rotor2(value,presets[2]);
						letter = rtr.alphabetInv(value);
						value = rtr.reflectorUKWC(letter);
						value = rtr.rotor2Inverse(value,presets[2]);
						value = rtr.rotor1Inverse(value,presets[1]);
						value = rtr.rotor4Inverse(value,presets[0]);
						letter = rtr.alphabetInv(value);
						lampBoard = plugboard[rtr.alphabet(letter)-1];
						System.out.print(lampBoard); 
					}

					if(rotors[2]==3)
					{
						letter = message.charAt(i);		
						letter = plugboard[rtr.alphabet(letter)-1];
						value = rtr.alphabet(letter);
						value = rtr.rotor4(value,presets[0]);
						value = rtr.rotor1(value,presets[1]);
						value = rtr.rotor3(value,presets[2]);
						letter = rtr.alphabetInv(value);
						value = rtr.reflectorUKWC(letter);
						value = rtr.rotor3Inverse(value,presets[2]);
						value = rtr.rotor1Inverse(value,presets[1]);
						value = rtr.rotor4Inverse(value,presets[0]);
						letter = rtr.alphabetInv(value);
						lampBoard = plugboard[rtr.alphabet(letter)-1];
						System.out.print(lampBoard); 
					}

					if(rotors[2]==5)
					{
						letter = message.charAt(i);		
						letter = plugboard[rtr.alphabet(letter)-1];
						value = rtr.alphabet(letter);
						value = rtr.rotor4(value,presets[0]);
						value = rtr.rotor1(value,presets[1]);
						value = rtr.rotor5(value,presets[2]);
						letter = rtr.alphabetInv(value);
						value = rtr.reflectorUKWC(letter);
						value = rtr.rotor5Inverse(value,presets[2]);
						value = rtr.rotor1Inverse(value,presets[1]);
						value = rtr.rotor4Inverse(value,presets[0]);
						letter = rtr.alphabetInv(value);
						lampBoard = plugboard[rtr.alphabet(letter)-1];
						System.out.print(lampBoard); 
					}
				}
				if(rotors[1]==2)
				{
					if(rotors[2]==1)
					{
						letter = message.charAt(i);		
						letter = plugboard[rtr.alphabet(letter)-1];
						value = rtr.alphabet(letter);
						value = rtr.rotor4(value,presets[0]);
						value = rtr.rotor2(value,presets[1]);
						value = rtr.rotor1(value,presets[2]);
						letter = rtr.alphabetInv(value);
						value = rtr.reflectorUKWC(letter);
						value = rtr.rotor1Inverse(value,presets[2]);
						value = rtr.rotor2Inverse(value,presets[1]);
						value = rtr.rotor4Inverse(value,presets[0]);
						letter = rtr.alphabetInv(value);
						lampBoard = plugboard[rtr.alphabet(letter)-1];
						System.out.print(lampBoard); 
					}

					if(rotors[2]==3)
					{
						letter = message.charAt(i);		
						letter = plugboard[rtr.alphabet(letter)-1];
						value = rtr.alphabet(letter);
						value = rtr.rotor4(value,presets[0]);
						value = rtr.rotor2(value,presets[1]);
						value = rtr.rotor3(value,presets[2]);
						letter = rtr.alphabetInv(value);
						value = rtr.reflectorUKWC(letter);
						value = rtr.rotor3Inverse(value,presets[2]);
						value = rtr.rotor2Inverse(value,presets[1]);
						value = rtr.rotor4Inverse(value,presets[0]);
						letter = rtr.alphabetInv(value);
						lampBoard = plugboard[rtr.alphabet(letter)-1];
						System.out.print(lampBoard); 
					}

					if(rotors[2]==5)
					{
						letter = message.charAt(i);		
						letter = plugboard[rtr.alphabet(letter)-1];
						value = rtr.alphabet(letter);
						value = rtr.rotor4(value,presets[0]);
						value = rtr.rotor2(value,presets[1]);
						value = rtr.rotor5(value,presets[2]);
						letter = rtr.alphabetInv(value);
						value = rtr.reflectorUKWC(letter);
						value = rtr.rotor5Inverse(value,presets[2]);
						value = rtr.rotor2Inverse(value,presets[1]);
						value = rtr.rotor4Inverse(value,presets[0]);
						letter = rtr.alphabetInv(value);
						lampBoard = plugboard[rtr.alphabet(letter)-1];
						System.out.print(lampBoard); 
					}
				}
				if(rotors[1]==3)
				{
					if(rotors[2]==1)
					{
						letter = message.charAt(i);		
						letter = plugboard[rtr.alphabet(letter)-1];
						value = rtr.alphabet(letter);
						value = rtr.rotor4(value,presets[0]);
						value = rtr.rotor3(value,presets[1]);
						value = rtr.rotor1(value,presets[2]);
						letter = rtr.alphabetInv(value);
						value = rtr.reflectorUKWC(letter);
						value = rtr.rotor1Inverse(value,presets[2]);
						value = rtr.rotor3Inverse(value,presets[1]);
						value = rtr.rotor4Inverse(value,presets[0]);
						letter = rtr.alphabetInv(value);
						lampBoard = plugboard[rtr.alphabet(letter)-1];
						System.out.print(lampBoard); 
					}

					if(rotors[2]==2)
					{
						letter = message.charAt(i);		
						letter = plugboard[rtr.alphabet(letter)-1];
						value = rtr.alphabet(letter);
						value = rtr.rotor4(value,presets[0]);
						value = rtr.rotor3(value,presets[1]);
						value = rtr.rotor2(value,presets[2]);
						letter = rtr.alphabetInv(value);
						value = rtr.reflectorUKWC(letter);
						value = rtr.rotor2Inverse(value,presets[2]);
						value = rtr.rotor3Inverse(value,presets[1]);
						value = rtr.rotor4Inverse(value,presets[0]);
						letter = rtr.alphabetInv(value);
						lampBoard = plugboard[rtr.alphabet(letter)-1];
						System.out.print(lampBoard); 
					}

					if(rotors[2]==5)
					{
						letter = message.charAt(i);		
						letter = plugboard[rtr.alphabet(letter)-1];
						value = rtr.alphabet(letter);
						value = rtr.rotor4(value,presets[0]);
						value = rtr.rotor3(value,presets[1]);
						value = rtr.rotor5(value,presets[2]);
						letter = rtr.alphabetInv(value);
						value = rtr.reflectorUKWC(letter);
						value = rtr.rotor5Inverse(value,presets[2]);
						value = rtr.rotor3Inverse(value,presets[1]);
						value = rtr.rotor4Inverse(value,presets[0]);
						letter = rtr.alphabetInv(value);
						lampBoard = plugboard[rtr.alphabet(letter)-1];
						System.out.print(lampBoard); 
					}
				}
				if(rotors[1]==5)
				{
					if(rotors[2]==1)
					{
						letter = message.charAt(i);		
						letter = plugboard[rtr.alphabet(letter)-1];
						value = rtr.alphabet(letter);
						value = rtr.rotor4(value,presets[0]);
						value = rtr.rotor5(value,presets[1]);
						value = rtr.rotor1(value,presets[2]);
						letter = rtr.alphabetInv(value);
						value = rtr.reflectorUKWC(letter);
						value = rtr.rotor1Inverse(value,presets[2]);
						value = rtr.rotor5Inverse(value,presets[1]);
						value = rtr.rotor4Inverse(value,presets[0]);
						letter = rtr.alphabetInv(value);
						lampBoard = plugboard[rtr.alphabet(letter)-1];
						System.out.print(lampBoard); 
					}

					if(rotors[2]==2)
					{
						letter = message.charAt(i);		
						letter = plugboard[rtr.alphabet(letter)-1];
						value = rtr.alphabet(letter);
						value = rtr.rotor4(value,presets[0]);
						value = rtr.rotor5(value,presets[1]);
						value = rtr.rotor2(value,presets[2]);
						letter = rtr.alphabetInv(value);
						value = rtr.reflectorUKWC(letter);
						value = rtr.rotor2Inverse(value,presets[2]);
						value = rtr.rotor5Inverse(value,presets[1]);
						value = rtr.rotor4Inverse(value,presets[0]);
						letter = rtr.alphabetInv(value);
						lampBoard = plugboard[rtr.alphabet(letter)-1];
						System.out.print(lampBoard); 
					}

					if(rotors[2]==3)
					{
						letter = message.charAt(i);		
						letter = plugboard[rtr.alphabet(letter)-1];
						value = rtr.alphabet(letter);
						value = rtr.rotor4(value,presets[0]);
						value = rtr.rotor5(value,presets[1]);
						value = rtr.rotor3(value,presets[2]);
						letter = rtr.alphabetInv(value);
						value = rtr.reflectorUKWC(letter);
						value = rtr.rotor3Inverse(value,presets[2]);
						value = rtr.rotor5Inverse(value,presets[1]);
						value = rtr.rotor4Inverse(value,presets[0]);
						letter = rtr.alphabetInv(value);
						lampBoard = plugboard[rtr.alphabet(letter)-1];
						System.out.print(lampBoard); 
					}
				}
			}

			if(rotors[0]==5)
			{
				if(rotors[1]==1)
				{
					if(rotors[2]==2)
					{
						letter = message.charAt(i);		
						letter = plugboard[rtr.alphabet(letter)-1];
						value = rtr.alphabet(letter);
						value = rtr.rotor5(value,presets[0]);
						value = rtr.rotor1(value,presets[1]);
						value = rtr.rotor2(value,presets[2]);
						letter = rtr.alphabetInv(value);
						value = rtr.reflectorUKWC(letter);
						value = rtr.rotor2Inverse(value,presets[2]);
						value = rtr.rotor1Inverse(value,presets[1]);
						value = rtr.rotor5Inverse(value,presets[0]);
						letter = rtr.alphabetInv(value);
						lampBoard = plugboard[rtr.alphabet(letter)-1];
						System.out.print(lampBoard); 
					}

					if(rotors[2]==3)
					{
						letter = message.charAt(i);		
						letter = plugboard[rtr.alphabet(letter)-1];
						value = rtr.alphabet(letter);
						value = rtr.rotor5(value,presets[0]);
						value = rtr.rotor1(value,presets[1]);
						value = rtr.rotor3(value,presets[2]);
						letter = rtr.alphabetInv(value);
						value = rtr.reflectorUKWC(letter);
						value = rtr.rotor3Inverse(value,presets[2]);
						value = rtr.rotor1Inverse(value,presets[1]);
						value = rtr.rotor5Inverse(value,presets[0]);
						letter = rtr.alphabetInv(value);
						lampBoard = plugboard[rtr.alphabet(letter)-1];
						System.out.print(lampBoard); 
					}

					if(rotors[2]==4)
					{
						letter = message.charAt(i);		
						letter = plugboard[rtr.alphabet(letter)-1];
						value = rtr.alphabet(letter);
						value = rtr.rotor5(value,presets[0]);
						value = rtr.rotor1(value,presets[1]);
						value = rtr.rotor4(value,presets[2]);
						letter = rtr.alphabetInv(value);
						value = rtr.reflectorUKWC(letter);
						value = rtr.rotor4Inverse(value,presets[2]);
						value = rtr.rotor1Inverse(value,presets[1]);
						value = rtr.rotor5Inverse(value,presets[0]);
						letter = rtr.alphabetInv(value);
						lampBoard = plugboard[rtr.alphabet(letter)-1];
						System.out.print(lampBoard); 
					}
				}
				if(rotors[1]==2)
				{
					if(rotors[2]==1)
					{
						letter = message.charAt(i);		
						letter = plugboard[rtr.alphabet(letter)-1];
						value = rtr.alphabet(letter);
						value = rtr.rotor5(value,presets[0]);
						value = rtr.rotor2(value,presets[1]);
						value = rtr.rotor1(value,presets[2]);
						letter = rtr.alphabetInv(value);
						value = rtr.reflectorUKWC(letter);
						value = rtr.rotor1Inverse(value,presets[2]);
						value = rtr.rotor2Inverse(value,presets[1]);
						value = rtr.rotor5Inverse(value,presets[0]);
						letter = rtr.alphabetInv(value);
						lampBoard = plugboard[rtr.alphabet(letter)-1];
						System.out.print(lampBoard); 
					}

					if(rotors[2]==3)
					{
						letter = message.charAt(i);		
						letter = plugboard[rtr.alphabet(letter)-1];
						value = rtr.alphabet(letter);
						value = rtr.rotor5(value,presets[0]);
						value = rtr.rotor2(value,presets[1]);
						value = rtr.rotor3(value,presets[2]);
						letter = rtr.alphabetInv(value);
						value = rtr.reflectorUKWC(letter);
						value = rtr.rotor3Inverse(value,presets[2]);
						value = rtr.rotor2Inverse(value,presets[1]);
						value = rtr.rotor5Inverse(value,presets[0]);
						letter = rtr.alphabetInv(value);
						lampBoard = plugboard[rtr.alphabet(letter)-1];
						System.out.print(lampBoard); 
					}

					if(rotors[2]==4)
					{
						letter = message.charAt(i);		
						letter = plugboard[rtr.alphabet(letter)-1];
						value = rtr.alphabet(letter);
						value = rtr.rotor5(value,presets[0]);
						value = rtr.rotor2(value,presets[1]);
						value = rtr.rotor4(value,presets[2]);
						letter = rtr.alphabetInv(value);
						value = rtr.reflectorUKWC(letter);
						value = rtr.rotor4Inverse(value,presets[2]);
						value = rtr.rotor2Inverse(value,presets[1]);
						value = rtr.rotor5Inverse(value,presets[0]);
						letter = rtr.alphabetInv(value);
						lampBoard = plugboard[rtr.alphabet(letter)-1];
						System.out.print(lampBoard); 
					}
				}
				if(rotors[1]==3)
				{
					if(rotors[2]==1)
					{
						letter = message.charAt(i);		
						letter = plugboard[rtr.alphabet(letter)-1];
						value = rtr.alphabet(letter);
						value = rtr.rotor5(value,presets[0]);
						value = rtr.rotor3(value,presets[1]);
						value = rtr.rotor1(value,presets[2]);
						letter = rtr.alphabetInv(value);
						value = rtr.reflectorUKWC(letter);
						value = rtr.rotor1Inverse(value,presets[2]);
						value = rtr.rotor3Inverse(value,presets[1]);
						value = rtr.rotor5Inverse(value,presets[0]);
						letter = rtr.alphabetInv(value);
						lampBoard = plugboard[rtr.alphabet(letter)-1];
						System.out.print(lampBoard); 
					}

					if(rotors[2]==2)
					{
						letter = message.charAt(i);		
						letter = plugboard[rtr.alphabet(letter)-1];
						value = rtr.alphabet(letter);
						value = rtr.rotor5(value,presets[0]);
						value = rtr.rotor3(value,presets[1]);
						value = rtr.rotor2(value,presets[2]);
						letter = rtr.alphabetInv(value);
						value = rtr.reflectorUKWC(letter);
						value = rtr.rotor2Inverse(value,presets[2]);
						value = rtr.rotor3Inverse(value,presets[1]);
						value = rtr.rotor5Inverse(value,presets[0]);
						letter = rtr.alphabetInv(value);
						lampBoard = plugboard[rtr.alphabet(letter)-1];
						System.out.print(lampBoard); 
					}

					if(rotors[2]==4)
					{
						letter = message.charAt(i);		
						letter = plugboard[rtr.alphabet(letter)-1];
						value = rtr.alphabet(letter);
						value = rtr.rotor5(value,presets[0]);
						value = rtr.rotor3(value,presets[1]);
						value = rtr.rotor4(value,presets[2]);
						letter = rtr.alphabetInv(value);
						value = rtr.reflectorUKWC(letter);
						value = rtr.rotor4Inverse(value,presets[2]);
						value = rtr.rotor3Inverse(value,presets[1]);
						value = rtr.rotor5Inverse(value,presets[0]);
						letter = rtr.alphabetInv(value);
						lampBoard = plugboard[rtr.alphabet(letter)-1];
						System.out.print(lampBoard); 
					}
				}
				if(rotors[1]==4)
				{
					if(rotors[2]==1)
					{
						letter = message.charAt(i);		
						letter = plugboard[rtr.alphabet(letter)-1];
						value = rtr.alphabet(letter);
						value = rtr.rotor5(value,presets[0]);
						value = rtr.rotor4(value,presets[1]);
						value = rtr.rotor1(value,presets[2]);
						letter = rtr.alphabetInv(value);
						value = rtr.reflectorUKWC(letter);
						value = rtr.rotor1Inverse(value,presets[2]);
						value = rtr.rotor4Inverse(value,presets[1]);
						value = rtr.rotor5Inverse(value,presets[0]);
						letter = rtr.alphabetInv(value);
						lampBoard = plugboard[rtr.alphabet(letter)-1];
						System.out.print(lampBoard); 
					}

					if(rotors[2]==2)
					{
						letter = message.charAt(i);		
						letter = plugboard[rtr.alphabet(letter)-1];
						value = rtr.alphabet(letter);
						value = rtr.rotor5(value,presets[0]);
						value = rtr.rotor4(value,presets[1]);
						value = rtr.rotor2(value,presets[2]);
						letter = rtr.alphabetInv(value);
						value = rtr.reflectorUKWC(letter);
						value = rtr.rotor2Inverse(value,presets[2]);
						value = rtr.rotor4Inverse(value,presets[1]);
						value = rtr.rotor5Inverse(value,presets[0]);
						letter = rtr.alphabetInv(value);
						lampBoard = plugboard[rtr.alphabet(letter)-1];
						System.out.print(lampBoard); 
					}

					if(rotors[2]==3)
					{
						letter = message.charAt(i);		
						letter = plugboard[rtr.alphabet(letter)-1];
						value = rtr.alphabet(letter);
						value = rtr.rotor5(value,presets[0]);
						value = rtr.rotor4(value,presets[1]);
						value = rtr.rotor3(value,presets[2]);
						letter = rtr.alphabetInv(value);
						value = rtr.reflectorUKWC(letter);
						value = rtr.rotor3Inverse(value,presets[2]);
						value = rtr.rotor4Inverse(value,presets[1]);
						value = rtr.rotor5Inverse(value,presets[0]);
						letter = rtr.alphabetInv(value);
						lampBoard = plugboard[rtr.alphabet(letter)-1];
						System.out.print(lampBoard); 
					}
				}
			}

		}

	}
}