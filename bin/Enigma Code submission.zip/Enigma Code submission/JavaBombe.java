import java.util.Scanner;

public class JavaBombe
{
	public static void main(String []args)
	{
		Scanner input = new Scanner(System.in);

		String code;
		String key;

		System.out.println("Enter the encrypted message.");
		code = input.nextLine();

		System.out.println("Enter the key word.");
		key = input.nextLine();



	}
}